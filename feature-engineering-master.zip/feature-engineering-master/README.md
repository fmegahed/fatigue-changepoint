# feature-engineering
The codes for preprocessing the IMU data to generate the required features.
